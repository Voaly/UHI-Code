var planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"];
var distance = [35, 67, 93, 142, 484, 889, 1079, 2800, 3670];
for (i = 0; i<planets.length; i++)
{
    document.write(`${planets[i]} is ${distance[i]} million miles away from the sun. <br>`);
}