var randomiser = 0;
var lotteryNumbers = new Array();
    for (i = 1; i<7; i++)
{
    var randomiser = Math.floor((Math.random() * 9) + 1);
    lotteryNumbers.push(randomiser);
}
lotteryNumbers.sort();
document.write(`The numbers are ${lotteryNumbers}`);