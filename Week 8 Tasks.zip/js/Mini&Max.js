var list = [2,6,3,4,6,9];
var min = 100;
var max = 0;
for( var i = 0; i < list.length; i++){
    if (list[i] > max){
        max = list[i];
    }
    if (list[i] < min){
        min = list[i];
    }
    alert(`The number of max is ${max} and the number for min is ${min}.`)
}