var names = ["AaDummy", "Aidan ","Emanuel ","Cody ","Daniel ","Jerry","Haiden ","Jasiu ","Kyle ","Liam ","Ethan ","Vaida ","Michael ","Andrew ","Jean ","Maks ","Leah ","Rowan","Paige","Stephen ","Harry ","Kaidyn"];
var numbers = 0;
var decision = 0;

while (decision != 1) {
    numbers = prompt(`Enter a number from 1 to ${names.length - 1}. You will obtain a name.`);
    if (numbers >0 && numbers <=21)
{
    break
}
else 
{
alert("Sorry, that number is not in the names array length, try again.");    
}
}
names.sort();
for (i = 1; i<22; i++)
{
    document.write(`${i}: ${names[i]} <br>`);
}
document.write(`The name you have got is ${names[numbers]}, which is number ${numbers}. Have a nice day.`);