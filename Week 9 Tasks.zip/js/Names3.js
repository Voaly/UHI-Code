//variables
var names = ["Woody", "Buzz", "Rex", "Hamm", "Jessie", "Woody", "Hamm", "Bo Peep", "Buzz", "Woody"];
var nameOccurence = 0;
var nameInArray = false;
//end of variables list


inputName = prompt("Please enter a name to search for. The available names are Woody, Buzz, Rex, Hamm, Jessie, or Bo Peep.");
//entering the name to search for

//list of all the names
for (i = 0; i<10; i++)
{
    document.write(`${i}: ${names[i]} <br><br>`);
}
//end of full name list

//searching for the name in the array
for (i = 0; i< names.length; i++){
    if (names [i] == inputName){
        document.write(names[i ], " is at array position " + i + "<br>");
        nameInArray = true;
        nameOccurence++
    }
}
//end of searching

//conditional statements
if (nameInArray == true && nameOccurence == 1) {
    document.write("<br>The name ", inputName, " appears ", nameOccurence, " time.");
}
else if (nameInArray == true && nameOccurence >=2){
    document.write("<br>The name ", inputName, " appears ", nameOccurence, " times.");
}
else if (nameInArray == false) {
    document.write("<br>No character with the name \"", inputName, "\" was found on the list.");
}
//end of conditional statements




//Mistakenly saved over each version, sorry about that.