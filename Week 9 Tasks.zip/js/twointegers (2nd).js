//starter variables
var decision = 0;
var firstNumber = 0;
var secondNumber = 0
var userChoice = 0;
//end of starter variables

//question, loop and decision
while (decision !=1){
    userChoice = prompt('Please choose one of the options here: (1 - Add) (2 - Difference) (3 - Multiply) (4 - Divide) (5 - Subtract) (6 - Remainder) ');
    if (userChoice <1 || userChoice >6){
        alert("It appears that the user choice you have entered is wrong, please try again.");
    }
    else{
        decision = decision + 1;
    }
}
//end of question, loop, and decision

//choosing the two numbers
firstNumber = parseInt(prompt("Please enter a number."));
secondNumber = parseInt(prompt("Please enter another number."));
//end of choosing two numbers

//functions
    function sumAdd() {
        var sum = 0;
        sum = (firstNumber + secondNumber);
        document.write("You have chosen sum, your number is ", sum, ".");
    }
    function sumProduct () {
        var product = 0
        product = (firstNumber * secondNumber);
        document.write("You have chosen product, your number is ", product, ".");
    }

    function sumDifference() {
        var difference = 0;
        difference = (firstNumber, secondNumber);
        document.write("You have chosen difference, your number is ", difference, ".");
    }

    function sumDivision(){
        var division = 0;
        division = (firstNumber / secondNumber);
        document.write("You have chosen division, your number is ", division, ".");
    }

    function sumRemainder (){
        var remainder = 0;
        remainder = (firstNumber % secondNumber);
        document.write("You have chosen remainder, your number is ", remainder, ".");
    }

    function sumMinus (){
        var subtract = 0;
        subtract = (firstNumber - secondNumber);
        document.write("You have chosen subtract, your number is ", subtract, ".");
    } //end of functions

//swtich statements
switch (userChoice) {
    case '1':
        sumAdd();
        break;
    case '2':
        sumDifference();
        break;
    case '3':
        sumProduct();
        break;
    case '4':
        sumDivision();
        break;
    case '5':
        sumMinus();
        break;
    case '6':
        sumRemainder();
    } //end of switch statements